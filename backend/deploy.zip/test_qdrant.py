import asyncio
import os
from dotenv import load_dotenv

load_dotenv()

async def main():
    try:
        from services.qdrant_service import qdrant_service
        print("Initialized Qdrant Service")
        
        # Test collections
        collections = await qdrant_service.async_client.get_collections()
        print(f"Success! Collections: {collections}")
    except Exception as e:
        print(f"Exception Type: {type(e)}")
        print(f"Exception String: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())
