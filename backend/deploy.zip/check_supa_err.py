import asyncio
from services.document_service import DocumentService

async def check():
    ds = DocumentService()
    res = ds.client.table('documents').select('filename, upload_status, error_message').order('created_at', desc=True).limit(5).execute()
    for doc in res.data:
        print(doc)

if __name__ == "__main__":
    asyncio.run(check())
