import asyncio
from qdrant_client import AsyncQdrantClient

async def main():
    # Use a blackhole IP to simulate a blocked port/dropped connection
    client = AsyncQdrantClient(
        url="https://10.255.255.1:6333",
        api_key="fake",
        timeout=3,
    )
    try:
        await client.get_collections()
    except Exception as e:
        print(f"Exception Type: {type(e)}")
        print(f"Exception String: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())
