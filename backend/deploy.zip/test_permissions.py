import asyncio
from qdrant_client import AsyncQdrantClient

async def test():
    client = AsyncQdrantClient(
        url='https://a07b797b-8b82-4455-a8a8-3eda35f7fbd4.us-east4-0.gcp.cloud.qdrant.io',
        api_key='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3MiOiJtIiwic3ViamVjdCI6ImFwaS1rZXk6M2M1ZWY0ODktZjgwYi00MjBhLTk2MGUtZDY2ZTYwNWRhNGYyIn0.xzv4BmRyRzax8WnikeU-sGXDBtF81Wky6RP4SV3B5ig'
    )
    print("Testing get_collections...")
    try:
        collections = await client.get_collections()
        print("Success!", collections)
    except Exception as e:
        print("Failed get_collections:", e)
        
    print("Testing create_collection...")
    try:
        await client.create_collection(
            collection_name="test_permissions",
            vectors_config={"size": 1536, "distance": "Cosine"}
        )
        print("Success!")
    except Exception as e:
        print("Failed create_collection:", e)
        
    print("Testing query_points...")
    try:
        res = await client.query_points('project_7037fe35-5279-42e3-af47-0df25a28ce8f', query=[0.1]*1536, limit=1)
        print("Success!")
    except Exception as e:
        print("Failed query_points:", e)

if __name__ == "__main__":
    asyncio.run(test())
