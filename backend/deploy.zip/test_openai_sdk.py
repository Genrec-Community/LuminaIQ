import asyncio
import os
from openai import AsyncAzureOpenAI

async def main():
    try:
        client = AsyncAzureOpenAI(
            azure_endpoint="https://liq.openai.azure.com/",
            api_key="AfQGLuBcbFKczn8zMh4EwqwusR6IkSniFmcisYyeLAxJfhbgzm7JJQQJ99CGACYeBjFXJ3w3AAABACOGJrBs",
            api_version="2024-12-01-preview",
            azure_deployment="gpt-5-mini"
        )
        
        response = await client.chat.completions.create(
            model="gpt-5-mini",
            messages=[{"role": "user", "content": "Hello"}],
            max_tokens=10
        )
        print(f"Success! Response: {response}")
    except Exception as e:
        print(f"Exception Type: {type(e)}")
        print(f"Exception String: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())
