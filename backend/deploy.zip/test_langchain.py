import asyncio
import os
from dotenv import load_dotenv

load_dotenv()

async def main():
    try:
        from langchain_openai import AzureChatOpenAI
        client = AzureChatOpenAI(
            azure_endpoint="https://liq.openai.azure.com/",
            api_key="AfQGLuBcbFKczn8zMh4EwqwusR6IkSniFmcisYyeLAxJfhbgzm7JJQQJ99CGACYeBjFXJ3w3AAABACOGJrBs",
            api_version="2024-12-01-preview",
            azure_deployment="gpt-5-mini"
        )
        response = await client.ainvoke("Hello")
        print(f"Success! Response: {response}")
    except Exception as e:
        print(f"Exception Type: {type(e)}")
        print(f"Exception String: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())
