import asyncio
import openai

async def main():
    try:
        client = openai.AsyncAzureOpenAI(
            azure_endpoint='https://thisdomaindoesnotexist123.openai.azure.com/',
            api_key='123',
            api_version='123',
            azure_deployment='gpt'
        )
        await client.chat.completions.create(model='gpt', messages=[{'role':'user','content':'hi'}])
    except Exception as e:
        print(f"Exception Type: {type(e)}")
        print(f"Exception String: {str(e)}")
        print(f"Repr: {repr(e)}")
        
if __name__ == "__main__":
    asyncio.run(main())
