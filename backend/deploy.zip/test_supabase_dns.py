import asyncio
from supabase import create_client, Client

def main():
    try:
        url: str = "https://thisdomaindoesnotexist123.supabase.co"
        key: str = "123"
        supabase: Client = create_client(url, key)
        supabase.table("users").select("*").execute()
    except Exception as e:
        print(f"Exception Type: {type(e)}")
        print(f"Exception String: {str(e)}")
        print(f"Repr: {repr(e)}")
        
if __name__ == "__main__":
    main()
