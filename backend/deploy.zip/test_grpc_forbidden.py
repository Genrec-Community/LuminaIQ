import asyncio
from qdrant_client import AsyncQdrantClient

async def test_grpc():
    client = AsyncQdrantClient(
        url='https://a07b797b-8b82-4455-a8a8-3eda35f7fbd4.us-east4-0.gcp.cloud.qdrant.io',
        api_key='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3MiOiJtIiwic3ViamVjdCI6ImFwaS1rZXk6M2M1ZWY0ODktZjgwYi00MjBhLTk2MGUtZDY2ZTYwNWRhNGYyIn0.xzv4BmRyRzax8WnikeU-sGXDBtF81Wky6RP4SV3B5ig',
        grpc_port=6334,
        prefer_grpc=True
    )
    print("Testing get_collections with gRPC...")
    try:
        collections = await client.get_collections()
        print("Success!", collections)
    except Exception as e:
        print("Failed get_collections:", repr(e))

if __name__ == "__main__":
    asyncio.run(test_grpc())
