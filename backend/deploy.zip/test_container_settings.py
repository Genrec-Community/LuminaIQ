import sys
sys.path.append('/app')
from config.settings import settings
print("AZURE_OPENAI_ENDPOINT:", settings.AZURE_OPENAI_ENDPOINT)
print("LLM_MODEL:", settings.LLM_MODEL)
print("AZURE_OPENAI_DEPLOYMENT:", settings.AZURE_OPENAI_DEPLOYMENT)
