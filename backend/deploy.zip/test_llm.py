import asyncio
import os
from dotenv import load_dotenv

load_dotenv()

async def main():
    try:
        from services.llm_service import llm_service
        print("Initialized LLM Service")
        
        response = await llm_service.chat_completion(
            messages=[{"role": "user", "content": "Hello"}],
            max_tokens=10
        )
        print(f"Success! Response: {response}")
    except Exception as e:
        print(f"Exception Type: {type(e)}")
        print(f"Exception String: {str(e)}")
        if hasattr(e, 'request'):
            print(f"Request URL: {e.request.url}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())
