import asyncio
from qdrant_client import AsyncQdrantClient

async def main():
    client = AsyncQdrantClient(
        url="https://a07b797b-8b82-4455-a8a8-3eda35f7fbd4.us-east4-0.gcp.cloud.qdrant.io",
        api_key="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3MiOiJtIiwic3ViamVjdCI6ImFwaS1rZXk6M2M1ZWY0ODktZjgwYi00MjBhLTk2MGUtZDY2ZTYwNWRhNGYyIn0.xzv4BmRyRzax8WnikeU-sGXDBtF81Wky6RP4SV3B5ig",
        timeout=10,
    )
    
    try:
        collections = await client.get_collections()
        print("Collections found:")
        for col in collections.collections:
            print(f" - {col.name}")
            
    except Exception as e:
        print(f"Failed to get collections: {e}")

if __name__ == "__main__":
    asyncio.run(main())
