import asyncio
from langchain_openai import AzureOpenAIEmbeddings

async def main():
    try:
        embeddings = AzureOpenAIEmbeddings(
            azure_endpoint="https://liq.openai.azure.com/",
            api_key="AfQGLuBcbFKczn8zMh4EwqwusR6IkSniFmcisYyeLAxJfhbgzm7JJQQJ99CGACYeBjFXJ3w3AAABACOGJrBs",
            api_version="2024-12-01-preview",
            azure_deployment="gpt-5-mini" # Invalid deployment for embeddings
        )
        response = await embeddings.aembed_query("Hello")
        print(f"Success! Response: {response[:5]}")
    except Exception as e:
        print(f"Exception Type: {type(e)}")
        print(f"Exception String: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())
