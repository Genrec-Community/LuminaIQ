import asyncio
import os
from supabase import create_client, Client

async def main():
    url = "https://bcosfvilvwyxtrctsmez.supabase.co"
    key = os.environ.get("SUPABASE_SERVICE_KEY")
    if not key:
        print("Please set SUPABASE_SERVICE_KEY")
        # Try anonymous key as fallback
        key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJjb3Nmdmlsdnd5eHRyY3RzbWV6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjY3ODIyMTMsImV4cCI6MjA4MjM1ODIxM30.bj9wwAT41fkvGX6CLrmyQT16-Fph4_mgqSXZintsNX0"

    supabase: Client = create_client(url, key)
    
    response = supabase.table("documents").select("*").order("created_at", desc=True).limit(5).execute()
    for doc in response.data:
        print(f"Doc: {doc['filename']}")
        print(f"Status: {doc['upload_status']}")
        print("-" * 20)

if __name__ == "__main__":
    asyncio.run(main())
