import asyncio
from qdrant_client import AsyncQdrantClient

async def main():
    client = AsyncQdrantClient(
        url="https://invalid-qdrant-domain.cloud.qdrant.io:6333",
        api_key="fake",
    )
    try:
        await client.get_collections()
    except Exception as e:
        print(f"Exception Type: {type(e)}")
        print(f"Exception String: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())
