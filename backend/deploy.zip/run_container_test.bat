@echo off
set "SCRIPT_B64=aW1wb3J0IHN5cwpzeXMucGF0aC5hcHBlbmQoJy9hcHAnKQpmcm9tIGNvbmZpZy5zZXR0aW5ncyBpbXBvcnQgc2V0dGluZ3MKcHJpbnQoIkFaVVJFX09QRU5BSV9FTkRQT0lOVDoiLCBzZXR0aW5ncy5BWlVSRV9PUEVOQUlfRU5EUE9JTlQpCnByaW50KCJMTE1fTU9ERUw6Iiwgc2V0dGluZ3MuTExNX01PREVMKQpwcmludCgiQVpVUkVfT1BFTkFJX0RFUExPWU1FTlQ6Iiwgc2V0dGluZ3MuQVpVUkVfT1BFTkFJX0RFUExPWU1FTlQpCg=="
az containerapp exec --name luminaiq-backend --resource-group LuminaIQ-RG --command "sh -c 'echo %SCRIPT_B64% | base64 -d > /tmp/test.py && python /tmp/test.py'"
