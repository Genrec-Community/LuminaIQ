import asyncio
from qdrant_client import AsyncQdrantClient

async def main():
    try:
        client = AsyncQdrantClient(url='https://thisdomaindoesnotexist123.qdrant.io:6333/')
        await client.get_collections()
    except Exception as e:
        print(f"Exception Type: {type(e)}")
        print(f"Exception String: {str(e)}")
        print(f"Repr: {repr(e)}")
        
if __name__ == "__main__":
    asyncio.run(main())
