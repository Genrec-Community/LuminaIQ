import asyncio
from services.embedding_service import EmbeddingService

async def test_embed():
    es = EmbeddingService()
    try:
        res = await es.embeddings.aembed_documents(["hello world"])
        print("Success! Embeddings length:", len(res))
    except Exception as e:
        print("Failed to embed:", repr(e))

if __name__ == "__main__":
    asyncio.run(test_embed())
